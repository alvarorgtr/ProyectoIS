
public class EmpleadoPDI extends Empleado {

	private String departamento;
	private String especialidad;
	private String despacho;
	private TipoDocente tipoDocente;

}
