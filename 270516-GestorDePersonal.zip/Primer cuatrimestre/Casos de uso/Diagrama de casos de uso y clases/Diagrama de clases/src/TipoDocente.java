
public enum TipoDocente {
	AYUDANTE, ASOCIADO, TITULAR, CATEDRATICO

}
