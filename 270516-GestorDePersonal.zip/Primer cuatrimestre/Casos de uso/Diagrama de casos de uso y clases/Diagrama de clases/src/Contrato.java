

import java.util.Date;
public class Contrato {

	private String cuentaBancaria;
	private int horasTrabajo;
	private Date fechaFin;
	private Boolean esTemporal;

}
