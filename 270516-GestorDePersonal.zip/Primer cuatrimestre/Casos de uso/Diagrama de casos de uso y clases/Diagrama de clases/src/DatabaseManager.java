
public class DatabaseManager {

	private boolean abierta;

	public Empleado consultarEmpleado(int idEmpleado) {
		return null;
	
	}

	public void abrirDatabase() {
	
	}

	public void a�adirEmpleado(Empleado empleado) {
	
	}

	public void eliminarEmpleado(int idEmpleado) {
	
	}

}
