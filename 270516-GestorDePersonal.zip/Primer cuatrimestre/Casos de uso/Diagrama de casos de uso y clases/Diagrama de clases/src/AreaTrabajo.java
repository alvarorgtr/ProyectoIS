
public enum AreaTrabajo {
	LIMPIEZA, MANTENIMIENTO, CAFETERIA

}
