
public enum TipoFacultad {
	MATEMATICAS, FISICA, QUIMICA, BIOLOGIA, INFORMATICA, MEDICINA, NINGUNA;

	private Usuario facultad;

}
