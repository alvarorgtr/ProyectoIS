

import java.lang.String;
public class Usuario {

	private String nombre;
	private String contrase�a;
	private TipoFacultad tipoFacultad;
	private TipoPermiso tipoPermiso;

}
