
public class EmpleadoPAS extends Empleado {

	private AreaTrabajo areaTrabajo;
	private String categoria;

}
