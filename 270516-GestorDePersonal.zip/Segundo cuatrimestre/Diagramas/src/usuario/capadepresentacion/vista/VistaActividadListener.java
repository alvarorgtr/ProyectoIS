package usuario.capadepresentacion.vista;

public interface VistaActividadListener {

	public void vistaAniadirUsuario();

	public void vistaEliminarUsuario();

	public void vistaAccesoEmpleados();
	
	public void logout();

}

