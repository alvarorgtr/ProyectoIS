package usuario.capadepresentacion.vista;

public interface VistaLoginUsuarioListener {

	void inicioSesion();

}
