package usuario.capadepresentacion.vista;


public interface VistaEliminarUsuarioListener{

	public void eliminar(String nombre);
	
}
