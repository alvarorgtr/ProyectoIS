package usuario.capadepresentacion.vista;

import usuario.capadenegocio.reglas.Usuario;
import empleado.capadepresentacion.vista.gestoreventos.BotonRetrocesoListener;

public interface VistaAniadirUsuarioListener extends BotonRetrocesoListener{

	void aniadir(Usuario user);

}
