package usuario.capadenegocio.reglas;

public interface Conserje {
	
	public Memento getMemento();
	public void setMemento(Memento memento);
	
}
