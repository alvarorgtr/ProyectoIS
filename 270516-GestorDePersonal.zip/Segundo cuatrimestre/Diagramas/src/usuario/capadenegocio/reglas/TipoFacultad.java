package usuario.capadenegocio.reglas;


public enum TipoFacultad {
	
	MATEMATICAS, FISICA, QUIMICA, BIOLOGIA, INFORMATICA, MEDICINA, NINGUNA;

}
