package usuario.capadenegocio.reglas;

import java.lang.String;

public class Usuario {

	private String nombre;
	private String contrasenia;
	private TipoFacultad tipoFacultad;
	private TipoPermiso tipoPermiso;
	
	public Usuario(String nombre, String contra, TipoFacultad tipoFacultad,
			TipoPermiso tipoPermiso) {
		this.nombre = nombre;
		this.contrasenia = contra;
		this.tipoFacultad = tipoFacultad;
		this.tipoPermiso = tipoPermiso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contra) {
		this.contrasenia = contra;
	}

	public TipoFacultad getTipoFacultad() {
		return tipoFacultad;
	}

	public void setTipoFacultad(TipoFacultad tipoFacultad) {
		this.tipoFacultad = tipoFacultad;
	}

	public TipoPermiso getTipoPermiso() {
		return tipoPermiso;
	}

	public void setTipoPermiso(TipoPermiso tipoPermiso) {
		this.tipoPermiso = tipoPermiso;
	}
	
}
