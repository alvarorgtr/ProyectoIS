package usuario.capadenegocio.transferencia;

import java.io.Serializable;

public class TransferNombre implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
	
	public TransferNombre(String nom){
		this.nombre = nom;
	}
	
	public String getNombre(){
		return nombre;
	}
	
}
