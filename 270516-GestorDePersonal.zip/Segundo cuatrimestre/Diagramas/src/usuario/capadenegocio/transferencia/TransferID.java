package usuario.capadenegocio.transferencia;

import java.io.Serializable;

public class TransferID implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
	private String contrasenia;
	
	public TransferID(String nom, String contra){
		this.nombre = nom;
		this.contrasenia = contra;
	}

	public String getNombre() {
		return nombre;
	}

	public String getContrasenia() {
		return contrasenia;
	}

}
