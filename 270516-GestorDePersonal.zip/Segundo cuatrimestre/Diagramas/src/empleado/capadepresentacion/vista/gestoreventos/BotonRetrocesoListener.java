package empleado.capadepresentacion.vista.gestoreventos;

public interface BotonRetrocesoListener {
	public void BotonRetrocesoPulsado();
}
