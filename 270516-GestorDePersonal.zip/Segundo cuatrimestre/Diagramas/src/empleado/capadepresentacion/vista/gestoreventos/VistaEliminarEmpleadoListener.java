package empleado.capadepresentacion.vista.gestoreventos;


public interface VistaEliminarEmpleadoListener extends BotonRetrocesoListener {
	public void eliminarEmpleado(int idEmpleado);
}
