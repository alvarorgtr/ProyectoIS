package empleado.capadepresentacion.vista;

public interface VistaGenerica {

	public void mostrarVista();

	public void ocultarVista();
	
}
