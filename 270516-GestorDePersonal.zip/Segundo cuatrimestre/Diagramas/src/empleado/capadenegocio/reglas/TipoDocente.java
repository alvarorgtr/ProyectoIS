package empleado.capadenegocio.reglas;

public enum TipoDocente {
	AYUDANTE, ASOCIADO, TITULAR, CATEDRATICO

}
