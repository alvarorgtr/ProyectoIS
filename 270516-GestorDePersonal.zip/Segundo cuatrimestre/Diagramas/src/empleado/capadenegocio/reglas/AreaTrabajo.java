package empleado.capadenegocio.reglas;

public enum AreaTrabajo {
	LIMPIEZA, MANTENIMIENTO, CAFETERIA

}
