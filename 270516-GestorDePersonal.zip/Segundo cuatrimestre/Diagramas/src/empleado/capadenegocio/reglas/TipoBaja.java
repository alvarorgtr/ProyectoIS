package empleado.capadenegocio.reglas;

public enum TipoBaja {
	TEMPORAL, PLANIFICADA, ALTA
}
