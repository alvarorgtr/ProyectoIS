

import java.lang.String;
public abstract class Empleado {

	protected String nombre;
	protected String apellido1;
	protected String apellido2;
	protected String path_foto;
	protected String direccion;
	private String[] idiomas;
	private String historialPath;
	private String nominaPath;
	private Contrato contrato;
	
}
